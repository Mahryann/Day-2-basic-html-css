# Day 2- Intro to css

Today i styled my html using a seperate file.

## Files Created
- 'Day2.html': A simple webpage with title, heading and paragraph
- 'Day2.css': CSS styles applied to make the page look better

## What i learned(A previous knowledge already)
- How to link a CSS file to an HTML file using <link>
- How to style text, background, and layout using CSS
- Basic CSS syntax: selectors,properties and values

## Styles Highlights
- beige background
- centered text
- styled heading and paragraph

## Next step
Learn more CSS properties and start making more structured layouts using divs and classes.(Already a previous knowledge) 